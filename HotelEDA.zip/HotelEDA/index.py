from sqlalchemy import create_engine as en
import pandas as pd

con=en("mysql+pymysql://root:sanjana***17@localhost:3306/day23")

data1=pd.read_sql("select h.hotel_id,h.hotel_name,h.hotel_address,h.city,h.country,h.rating,h.total_rooms,r.room_type,r.availability,r.price_per_night from hotels_large as h inner join rooms_large as r on h.hotel_id=r.hotel_id;",con)
print(data1)

# x="sanjan"
# y=""
# i=len(x)-1
# while i>=0:
#     y+=i
#     print(y)